from nepse_scraper.Scraper import Request_module
